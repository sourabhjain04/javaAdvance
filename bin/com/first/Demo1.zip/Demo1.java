package com.first;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Math.max(9, 7));
	}

}
