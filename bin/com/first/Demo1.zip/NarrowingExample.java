package com.first;

public class NarrowingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double doubleValue=99.99;
		int intValue = (int) doubleValue; //Explicit conversion.
		
		System.out.println("double value "+ doubleValue);
		System.out.println("Integer Value " + intValue);
		
		
	}

}
