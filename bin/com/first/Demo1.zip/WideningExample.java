package com.first;

public class WideningExample {
 public static void main(String[] args) {
	
	 int num = 50;
	 double doubleNum= num; //Automatic Conversion 
	 
	 System.out.println("Interger value "+ num);
	 System.out.println("Double value"+ doubleNum);
}
}
