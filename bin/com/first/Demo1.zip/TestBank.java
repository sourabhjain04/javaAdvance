package com.first;

interface Bank{
	 abstract int getROI();
	
}

class SBI implements Bank{

	@Override
	public int getROI() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}

class HDFC implements Bank{

	@Override
	public int getROI() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}


public class TestBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
