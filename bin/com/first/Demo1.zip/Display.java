package com.first;

public class Display {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		show();
		
	}
	
	
	static void show() {
		System.out.println("it is an example of static method");
	}

}
